package com.gmx0807.view.dept;

public interface Io {
	public void edit();
}
