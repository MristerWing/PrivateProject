package ch01;

public class Pro6 {

	public static void main(String[] args) {
		int num = 24;
		
		System.out.println((((num / 10) + 1) * 10) - num);
		
//		or
//		System.out.println(10 - (num % 10));

	}

}
