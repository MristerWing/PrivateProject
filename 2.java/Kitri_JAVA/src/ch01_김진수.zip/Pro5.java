package ch01;

public class Pro5 {

	public static void main(String[] args) {
		int num = 333;
		
		System.out.println((num / 10) * 10 + 1);

	}

}
