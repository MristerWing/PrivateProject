package ex;

public class CodeValueNotFoundException extends Exception{
	static final long serialVersionUID = -15964465462L;
	
	public CodeValueNotFoundException() {
		super();
	}
	
	public CodeValueNotFoundException(String s) {
		super(s);
	}
	
	
}
