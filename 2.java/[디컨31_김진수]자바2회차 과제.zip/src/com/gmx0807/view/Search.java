package com.gmx0807.view;

public abstract class Search extends InputMSG {
	
	//all data view
	public abstract void allView();
	
	//select data view
	public abstract void selectView(Object obj);
	
}
